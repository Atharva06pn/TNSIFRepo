import java.util.Random;
import java.util.Scanner;

public class Dice_Game_Atharva_Kalbhor_T090800608 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        
        System.out.println("*********************************");
        System.out.println("*        WELCOME TO THE        *");
        System.out.println("*        DICE GAME SHOW        *");
        System.out.println("*********************************");
        
        boolean playAgain = true;
        while (playAgain) {
            System.out.println("\n\n");
            
            System.out.print("🎲 Player 1, press Enter to roll the dice... 🎲");
            scanner.nextLine();
            int player1Roll = random.nextInt(6) + 1;
            System.out.println("🎲 Player 1 rolled: " + player1Roll + " 🎲");
            
            System.out.println("\n\n");
            
            System.out.print("🎲 Player 2, press Enter to roll the dice... 🎲");
            scanner.nextLine();
            int player2Roll = random.nextInt(6) + 1;
            System.out.println("🎲 Player 2 rolled: " + player2Roll + " 🎲");
            
            System.out.println("\n\n");
            
            System.out.println("*********************************");
            if (player1Roll > player2Roll) {
                System.out.println("🎉🎉 Player 1 wins! 🎉🎉");
            } else if (player2Roll > player1Roll) {
                System.out.println("🎉🎉 Player 2 wins! 🎉🎉");
            } else {
                System.out.println("🤝 It's a draw! 🤝");
            }
            System.out.println("*********************************");
            
            System.out.print("Do you want to play again? (yes/no): ");
            String response = scanner.nextLine().trim().toLowerCase();
            playAgain = response.equals("yes");
        }
        
        System.out.println("Thanks for playing! 🎲✨");
        scanner.close();
    }
}
